-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: k4a102.p.ssafy.io    Database: moasup
-- ------------------------------------------------------
-- Server version	8.0.25-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `picture_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `voice_path` varchar(200) NOT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `comment_picture_idx` (`picture_id`),
  KEY `commnet_user_idx` (`user_id`),
  CONSTRAINT `comment_picture` FOREIGN KEY (`picture_id`) REFERENCES `picture` (`picture_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `commnet_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (12,52,15,'k4a102.p.ssafy.io/backend/voice/20210520143011.wav'),(29,70,15,'k4a102.p.ssafy.io/backend/voice/20210520175204.wav'),(30,69,15,'k4a102.p.ssafy.io/backend/voice/20210520175528.wav'),(31,70,15,'k4a102.p.ssafy.io/backend/voice/20210520175634.wav'),(33,69,15,'k4a102.p.ssafy.io/backend/voice/20210520180834.wav'),(35,53,15,'k4a102.p.ssafy.io/backend/voice/20210520220141.wav');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `family`
--

DROP TABLE IF EXISTS `family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `family` (
  `family_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`family_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family`
--

LOCK TABLES `family` WRITE;
/*!40000 ALTER TABLE `family` DISABLE KEYS */;
INSERT INTO `family` VALUES (1,'행복한 사피생활'),(3,'행복한 사피생활'),(21,'새가족'),(25,'심슨가족'),(26,'짱구네가족'),(27,'싸피가족');
/*!40000 ALTER TABLE `family` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `notice_id` int NOT NULL AUTO_INCREMENT,
  `family_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `content` varchar(45) DEFAULT NULL,
  `date` timestamp NOT NULL,
  PRIMARY KEY (`notice_id`),
  KEY `notice_family_idx` (`family_id`),
  KEY `notice_user_idx` (`user_id`),
  CONSTRAINT `notice_family` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notice_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,1,3,'행복한 어린이날','다들 어린이대공원에서 만나요','2021-04-30 10:15:00'),(4,1,3,'할아버지 생신','곧 할아버지 생신입니다. 다들 시간 비워두세요!!','2021-05-03 07:06:01'),(6,1,3,'가족등산','등산이 예정되어 있어요','2021-05-18 02:13:48'),(18,1,15,'돌잔치','참석합시다','2021-05-20 00:57:32'),(19,25,20,'테스트','테스트 글을 작성해 보았습니다.','2021-05-20 06:55:52'),(24,1,15,'곧 결혼기념일 이에요!!','벌써 3주년이나 되었답니다','2021-05-20 08:24:22'),(32,26,4,'반가워요','반갑습니다!!','2021-05-20 15:42:33');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picture`
--

DROP TABLE IF EXISTS `picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `picture` (
  `picture_id` int NOT NULL AUTO_INCREMENT,
  `family_id` int DEFAULT NULL,
  `image_path` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`picture_id`),
  KEY `picture_family_idx` (`family_id`),
  CONSTRAINT `picture_family` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picture`
--

LOCK TABLES `picture` WRITE;
/*!40000 ALTER TABLE `picture` DISABLE KEYS */;
INSERT INTO `picture` VALUES (52,1,'k4a102.p.ssafy.io/backend/picture/20210520140519file.dat'),(53,1,'k4a102.p.ssafy.io/backend/picture/20210520141214file.dat'),(54,1,'k4a102.p.ssafy.io/backend/picture/20210520141516file.dat'),(56,1,'k4a102.p.ssafy.io/backend/picture/20210520142652file.dat'),(57,1,'k4a102.p.ssafy.io/backend/picture/20210520143752file.dat'),(58,1,'k4a102.p.ssafy.io/backend/picture/20210520143800file.png'),(60,1,'k4a102.p.ssafy.io/backend/picture/20210520144003file.dat'),(61,1,'k4a102.p.ssafy.io/backend/picture/20210520144314file.dat'),(65,25,'k4a102.p.ssafy.io/backend/picture/20210520155520file.dat'),(69,1,'k4a102.p.ssafy.io/backend/picture/20210520172838file.dat'),(70,1,'k4a102.p.ssafy.io/backend/picture/20210520173033file.dat');
/*!40000 ALTER TABLE `picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `family_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `content` varchar(45) DEFAULT NULL,
  `date` timestamp NOT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `schedule_family_idx` (`family_id`),
  KEY `schedule_user_idx` (`user_id`),
  CONSTRAINT `schedule_family` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`),
  CONSTRAINT `schedule_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,1,3,'이번주 모임 취소','이태원 파티 망함','0000-00-00 00:00:00'),(3,1,3,'date추가 ㅇㅇㅇ','날짜테스트','2021-05-03 07:28:34');
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(45) NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `id_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (3,'test@test.com','김사피','1234'),(4,'son001','짱구','1234'),(5,'mom0517','봉미선','1234'),(6,'dau02','짱아','1234'),(7,'0102dad','신형만','1234'),(13,'id123','nickn','1234'),(14,'id1234','nn','1234'),(15,'ssafy123','김싸피','1234'),(16,'sub0102','첫째아들','1234'),(17,'sub0101','nick','1234'),(18,'myname','nick','1234'),(19,'12','12','12'),(20,'lab1.ssafy','싸피랩','ssafy1234'),(21,'111','111','111'),(22,'222','222','222');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_family`
--

DROP TABLE IF EXISTS `user_family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_family` (
  `user_id` int DEFAULT NULL,
  `family_id` int DEFAULT NULL,
  KEY `user_family_idx` (`user_id`),
  KEY `family_user_idx` (`family_id`),
  CONSTRAINT `family_user` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_family` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_family`
--

LOCK TABLES `user_family` WRITE;
/*!40000 ALTER TABLE `user_family` DISABLE KEYS */;
INSERT INTO `user_family` VALUES (15,1),(14,21),(3,1),(19,1),(20,25),(4,26),(5,26),(6,26),(7,26),(21,27),(22,1);
/*!40000 ALTER TABLE `user_family` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-21  9:57:11
